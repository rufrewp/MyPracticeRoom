#include <math.h>
#include "task7_func.h"

void f(void) {
	result = pow(cos(x) - cos(y), 2.0) - pow(sin(x) - sin(y), 2.0);
}
