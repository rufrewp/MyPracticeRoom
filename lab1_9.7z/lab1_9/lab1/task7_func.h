double x, y, result;

void f(void);
